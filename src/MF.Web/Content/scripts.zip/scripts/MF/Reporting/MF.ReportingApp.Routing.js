/**
 * Created by JetBrains RubyMine.
 * User: Owner
 * Date: 2/26/12
 * Time: 11:22 AM
 * To change this template use File | Settings | File Templates.
 */
MF.Routing.ReportingApp = (function(MF, Backbone){
    var ReportingApp = {};

    // Initialize the router when the application starts
    MF.addInitializer(function(){
//        BillingApp.router = new BillingApp.Router({
//            controller: MF.Controller
//        });
    });

    return ReportingApp;
})(MF, Backbone);
